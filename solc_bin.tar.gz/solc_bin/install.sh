#!/usr/bin/env bash

echo "Installing solc dep lib"
sudo install lib/libsol* /usr/lib
sudo install lib/libstdc++.so.6 /usr/local/lib
sudo install lib/libgcc_s.so.1 /usr/local/lib
# Warning: mv to /usr/lib, not /usr/local/lib
sudo install lib/libboost* /usr/lib
sudo install lib/libicu* /usr/lib
echo "solc dep lib installed at /usr/local/lib"
echo "Installing solc"
sudo install bin/solc /usr/local/bin
echo "solc installed at /usr/local/bin"
