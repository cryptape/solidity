#!/usr/bin/env bash

echo "Installing solc dep lib"	
sudo install lib/libsol* /usr/local/lib
echo "solc dep lib installed at /usr/local/lib"
echo "Installing solc"
sudo install bin/solc /usr/local/bin
echo "solc installed at /usr/local/bin"
