## use the binary file to install solc compiler

1. only need to run the script at current direct(solc_bin):

```
./install.sh
```

the solc compiler will be intalled at ```/usr/local/bin```


2. you can also install all required external dependencies:

```
./install_deps.sh
```
